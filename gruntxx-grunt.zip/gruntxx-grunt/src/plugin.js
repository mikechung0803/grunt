function aa(){
    console.log('aa');
}