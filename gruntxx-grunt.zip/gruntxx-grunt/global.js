function aa(){
    console.log('aa');
}
function bb(){
    console.log('bb');
}